/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame.sfx;

/**
 *
 * @author ZePedro
 */
public class Explosion {
    
}
