/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package mygame.superPower;


public enum ESuperPower {
    None,Informatic,Civil,Chemistry,Eletro,Bio,Mechanics,Metal
}
